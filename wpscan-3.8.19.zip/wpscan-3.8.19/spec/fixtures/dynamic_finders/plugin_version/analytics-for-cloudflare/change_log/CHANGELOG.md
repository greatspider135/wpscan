# Analytics For Cloudflare

## 1.1 - 2017-02-09
### Fixed
  - Match Wordpress-Extra coding standards.
  - Fix text domain in i18n (make static instead of variable).
  - Fix domains not appearing properly if you have more than 20

## 1.0.2 - 2015-11-26
### Added
 - Developer hooks to filter api values

 ### Fixed
  - Update to WordPress coding standards

## 1.0.1 - 2015-11-23
### Added
 - Link to settings from the plugin page

### Fixed
 - Internationalization not enabled.

## 1.0.0 - 2015-11-09
- The initial release of this plugin
