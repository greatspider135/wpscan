# Changelog

## 1.3
- New: Removed OB features

## 1.2
- New: Added option to allow only embed or social share on front-end
- New: Made the popup compatible with badgeOS Congratulation add-on popup
- Fix: UI Tweaks

## 1.1
- New: Option to display social sharing popup on badge award
- New: Option to display social sharing option with BadgeOS earned achievement shortcode
- New: Option to share badges to social media from front-end
- Fix: Fixed email image issue
- Fix: string translation issues in email

## 1.0
- Initial





