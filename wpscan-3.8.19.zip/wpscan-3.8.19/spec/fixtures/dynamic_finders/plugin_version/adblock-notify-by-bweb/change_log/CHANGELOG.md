
### v2.4.0 - 2019-03-21
**Changes:**
- Upgraded Freemius SDK.
- Integration with Admiral (http://getadmiral.com).

 ### v2.2.3 - 2017-08-16
 **Changes:**

 ### v2.2.2 - 2017-08-14
 **Changes:**
 * Small improvement with themes compatibility.

 ### v2.2.1 - 2017-05-11
 **Changes:**
 - Updated contributors and links.
- Added new stack repo.

 ### v2.2.0 - 2017-05-11
 **Changes:**
 - Removed AdBlock name due to copyright conflict.
- Added new deployment stack.

### 2.1.0 - 12/01/2017
**Changes:**
- Fixed reset stats error
- Fixed icon menu
- Fixed dashboard widget showing for non-admins

### 2.0.12 - 06/12/2016
**Changes:**
- Fixed issue with popup showing on the footer

### 2.0.11 - 23/11/2016
**Changes:**
- adblock-notify-by-bweb Fixed upgrade issue which was recreating js and css files
- adblock-notify-by-bweb Fixed issue with modal options on https websites

### 2.0.10 - 21/11/2016
**Changes:**
- Added option to block popup dismiss
- Fixed bug with admin dashboard design

### 2.0.9 - 07/11/2016
**Changes:**
- Fixed css issue with popup at the end of the page.

### 2.0.8 - 01/11/2016
**Changes:**
- Added freemius support

### 2.0.7 - 31/10/2016
**Changes:**
- remove redundant files

### 2.0.6 - 31/10/2016
**Changes:**
- Fixed issue with popup location
- Fixed issue with upgrade routines

### 2.0.5 - 28/10/2016
**Changes:**
- Fixed tracking link

### 2.0.4 - 28/10/2016
**Changes:**
- Fixed style for dashboard widgets.

### 2.0.3 - 27/10/2016
**Changes:**
- Fixed issue with widget now showing in admin dashboard

### 2.0.2 - 24/10/2016
**Changes:**
- Added tweak for AdBlock in admin area

### 2.0.1 - 24/10/2016
**Changes:**
- Fixed issue with updates for old users

### 2.0.0 - 21/10/2016
**Changes:**
- Tested on WP 4.6.1 with success!
- Added compatibility with pro plugin
- Added support for popup templates inside the theme used
- Added support for multisite

