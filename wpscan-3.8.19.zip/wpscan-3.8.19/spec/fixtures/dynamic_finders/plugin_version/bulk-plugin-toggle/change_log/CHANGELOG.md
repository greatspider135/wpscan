# Changelog

## 1.0.1 _(2021-07-13)_
* Change: Note compatibility through WP 5.7+
* Change: Add a tad more to the plugin's longer description
* Change: Update copyright date (2021)
* Change: Trivial code tweaks
* Change: Fix typo in inline parameter documentation
* Change: Unit tests: Move `phpunit/` into `tests/`

## 1.0 _(2020-08-07)_
* Initial public release.