# Changelog

## [Unreleased]

## [1.2.0] - 2019-03-09
### Added
* (09 March 2019).
* Clickable tags.
* Upload your own image as a background.


## [1.1.0] - 2017-06-23
### Added
* (23 June 2017). Settings Button for plugins page.

## [1.0.0] - 2017-06-20
* (19 June 2017). Revived ID system.
* (19 June 2017). Added Widget.
* (18 June 2017). Change documentation and coding standards.

