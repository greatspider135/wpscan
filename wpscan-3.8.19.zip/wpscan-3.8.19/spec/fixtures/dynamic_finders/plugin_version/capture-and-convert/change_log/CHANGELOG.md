
## 1.4.2

- Added Changelog
- Fixed bug with widgets
- Fixed bug with Twitter auth token
