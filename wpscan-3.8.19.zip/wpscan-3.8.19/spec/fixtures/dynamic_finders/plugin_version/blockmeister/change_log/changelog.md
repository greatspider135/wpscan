# Change Log

## [2.0.1] - 2020-09-03 ##

### Fixed
- keywords taxonomy's edit capability

## [2.0.0] - 2020-08-20
First public release.

### Fixed
- refactored complete 1.0 code set

### Added
- block settings menu item to add selected blocks to a new block pattern
- category taxonomy
- keyword taxonomy
- viewport width setting
- limit pattern building to administrators
- admin capabilities
- made translatable
- Dutch translation

## [1.0.x] - 2020-07-10
Private releases
